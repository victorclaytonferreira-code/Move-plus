# MOVE+ Android — Versão 1

Projeto Android funcional da MOVE+.

## Incluído
- Tela inicial
- Saldo demonstrativo
- Cartões Idoso, Criança, Adulto e Vale
- Regras de benefícios
- Serviços de ônibus, bikes e patinetes elétricos
- Mapa demonstrativo
- Histórico
- Perfil e bloqueio demonstrativo

## Como abrir
1. Instale o Android Studio.
2. Abra a pasta `MOVE_plus_Android_v1`.
3. Aguarde a sincronização do Gradle.
4. Clique em Run ▶ para instalar no celular/emulador.

Esta versão é um protótipo funcional: PIX, GPS, banco de dados e pagamentos reais ainda são simulados.
