package br.com.moveplus.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private lateinit var title: TextView
    private var saldo = 35.00

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildShell()
        showHome()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 18)
            setBackgroundColor(Color.rgb(8,123,67))
        }

        title = TextView(this).apply {
            text = "MOVE+"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(title)

        val subtitle = TextView(this).apply {
            text = "Mobilidade 100% elétrica"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        header.addView(subtitle)

        root.addView(header)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 90)
        }

        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(5, 7, 5, 7)
            setBackgroundColor(Color.WHITE)
        }

        nav.addView(navButton("⌂", "Início") { showHome() })
        nav.addView(navButton("💳", "Cartões") { showCards() })
        nav.addView(navButton("🗺", "Mapa") { showMap() })
        nav.addView(navButton("▣", "Histórico") { showHistory() })
        nav.addView(navButton("👤", "Perfil") { showProfile() })

        root.addView(nav)
        setContentView(root)
    }

    private fun navButton(icon: String, label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = "$icon\n$label"
            textSize = 11f
            setTextColor(Color.rgb(8,123,67))
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, 62, 1f)
        }
    }

    private fun heading(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 23f
            setTextColor(Color.rgb(23,35,28))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 14)
        })
    }

    private fun card(text: String, color: Int = Color.rgb(233,247,239), click: (() -> Unit)? = null): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.rgb(23,35,28))
            setPadding(20, 20, 20, 20)
            setBackgroundColor(color)
            if (click != null) setOnClickListener { click() }
            content.addView(this, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 0, 0, 14)
            })
        }
    }

    private fun showHome() {
        content.removeAllViews()
        heading("Olá! 👋")
        card("SALDO MOVE+\nR$ %.2f\n\nToque para adicionar crédito".format(saldo), Color.rgb(8,123,67)) {
            Toast.makeText(this, "Recarga via PIX: funcionalidade de demonstração", Toast.LENGTH_LONG).show()
        }.setTextColor(Color.WHITE)

        heading("Serviços")
        card("🚌  Ônibus elétricos\nTransporte coletivo silencioso e sustentável.") { service("Ônibus elétricos") }
        card("🚲  Bicicletas elétricas\nEncontre uma bike e movimente-se pela cidade.") { service("Bicicletas elétricas") }
        card("🛴  Patinetes elétricos\nMobilidade rápida para pequenos deslocamentos.") { service("Patinetes elétricos") }

        heading("Seu MOVE+")
        card("💳 Cartão ativo: MOVE+ Adulto\nBenefício: a cada 6 utilizações, a 7ª é grátis.") { showCards() }
    }

    private fun service(name: String) {
        Toast.makeText(this, "$name selecionado", Toast.LENGTH_SHORT).show()
    }

    private fun showCards() {
        content.removeAllViews()
        heading("Cartões MOVE+")
        card("🟣 MOVE+ Idoso\n60 anos ou mais • passagem por R$ 2,00", Color.rgb(242,232,250)) {
            detail("MOVE+ Idoso", "Para passageiros com 60 anos ou mais.", "Passagem por R$ 2,00.", "Acessibilidade e praticidade.")
        }
        card("🟠 MOVE+ Criança\nA cada 4 utilizações, a 5ª é grátis.", Color.rgb(255,240,225)) {
            detail("MOVE+ Criança", "Para crianças cadastradas.", "A cada 4 utilizações, a 5ª passagem sai grátis.", "Cartão identificado por categoria.")
        }
        card("🔴 MOVE+ Adulto\nA cada 6 utilizações, a 7ª é grátis.", Color.rgb(255,232,234)) {
            detail("MOVE+ Adulto", "Para passageiros adultos.", "A cada 6 utilizações, a 7ª passagem sai grátis.", "Uso nos serviços elétricos MOVE+.")
        }
        card("🟢 MOVE+ Vale\nVale-transporte em um só cartão.", Color.rgb(229,247,238)) {
            detail("MOVE+ Vale", "Para trabalhadores que recebem vale-transporte.", "Créditos para deslocamentos de trabalho.", "Controle de créditos e praticidade.")
        }
    }

    private fun detail(name: String, who: String, rule: String, benefit: String) {
        content.removeAllViews()
        heading(name)
        card("QUEM PODE USAR\n$who")
        card("REGRA\n$rule")
        card("BENEFÍCIOS\n$benefit")
        val b = Button(this).apply {
            text = "← Voltar para cartões"
            setOnClickListener { showCards() }
        }
        content.addView(b)
    }

    private fun showMap() {
        content.removeAllViews()
        heading("Mapa MOVE+ 🗺️")
        card("📍 MAPA DE DEMONSTRAÇÃO\n\n🚌 12 ônibus elétricos\n🚲 28 bicicletas disponíveis\n🛴 41 patinetes disponíveis\n\nA localização GPS real será conectada em uma próxima versão.")
        card("🔎 Procurar veículo\nEscolha um serviço acima para visualizar disponibilidade.") {
            Toast.makeText(this, "Busca de veículos em desenvolvimento", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showHistory() {
        content.removeAllViews()
        heading("Histórico")
        card("Hoje • 07:42\n🚌 Ônibus elétrico\nR$ 5,00")
        card("Ontem • 18:16\n🛴 Patinete elétrico\nR$ 3,50")
        card("Ontem • 08:05\n🚲 Bicicleta elétrica\nR$ 4,00")
        card("Total do período: R$ 12,50")
    }

    private fun showProfile() {
        content.removeAllViews()
        heading("Meu perfil 👤")
        card("Victor\nCartão principal: MOVE+ Adulto\nStatus: Ativo")
        card("🔒 Bloquear cartão") {
            Toast.makeText(this, "Cartão bloqueado (demonstração)", Toast.LENGTH_LONG).show()
        }
        card("⚙️ Configurações")
        card("ℹ️ Sobre a MOVE+\nMobilidade 100% elétrica para a cidade.")
    }
}
